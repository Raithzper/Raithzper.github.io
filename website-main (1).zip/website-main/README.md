# website
Just a site that I will be using to show my learning progress in HTML. It also makes me remember on how many times I have smashed my head in the keyboard on why the code is not working :)
